# from __future__ import absolute_import
# from __future__ import division
# from __future__ import print_function
#
# import argparse
# import torch
# import torchvision
# from torchvision import transforms
# from torch.utils.data.dataloader import DataLoader
# from torch.nn import CrossEntropyLoss
# from torch import optim
# import time
# from cnn_model import CNN
# from dataset import MyDataset
# import json
#
# # Default constants
# LEARNING_RATE_DEFAULT = 1e-4
# BATCH_SIZE_DEFAULT = 64
# MAX_EPOCHS_DEFAULT = 2000
# EVAL_FREQ_DEFAULT = 10
# WEIGHT_PENAL_DEFAULT = 0.0
# USING_GPU_DEFAULT = True
# DATA_AUGMENTATION_DEFAULT = True
# OPTIMIZER_DEFAULT = 'ADAM'
# THREADS_DEFAULT = 8
# save_freq = 250
#
# FLAGS = None
#
# RESULT_PATH_DEFAULT = 'CNN_original'
#
# # transform = transforms.Compose(
# #     [transforms.ToTensor(),
# #      transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
#
# def accuracy(model, data_loader):
#     """
#     Computes the prediction accuracy, i.e., the average of correct predictions
#     of the network.
#     Args:
#         predictions: 2D float array of size [number_of_data_samples, n_classes]
#         labels: 2D int array of size [number_of_data_samples, n_classes] with one-hot encoding of ground-truth labels
#     Returns:
#         accuracy: scalar float, the accuracy of predictions.
#     """
#     model.eval()
#
#     correct = torch.zeros(1).squeeze()
#     total = torch.zeros(1).squeeze()
#
#     if gpu:
#         correct = correct.cuda()
#         total = total.cuda()
#
#     for i, (X, Y) in enumerate(data_loader):
#         if gpu:
#             X = X.cuda()
#             Y = Y.cuda()
#
#         output = model(X)
#
#         prediction = torch.argmax(output, 1)
#         correct += (prediction == Y).sum().float()
#         total += len(Y)
#     model.train()
#     return float((correct / total).cpu())
#
#
# def train(gpu=False):
#     """
#     Performs training and evaluation of MLP model.
#     NOTE: You should the model on the whole test set each eval_freq iterations.
#     """
#     # YOUR TRAINING CODE GOES HERE
#     # model = CNN(3, 10)
#     model = CNN()
#     gpu = gpu and torch.cuda.is_available()
#     if gpu:
#         model = model.cuda()
#     loss_func = CrossEntropyLoss()
#     loss_func = loss_func.cuda()
#     optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_penal)
#     loss_data = []
#     accu_data = []
#
#     start_time = time.time()
#
#     for ep in range(max_steps):
#         mean_loss = 0.0
#
#         if ep == 50:
#             optimizer = optim.Adam(model.parameters(), lr=lr/5, weight_decay=weight_penal)
#         elif ep == 500:
#             optimizer = optim.Adam(model.parameters(), lr=lr/25, weight_decay=weight_penal)
#
#         for X, Y in train_loader:
#             if gpu:
#                 X = X.cuda()
#                 Y = Y.cuda()
#             optimizer.zero_grad()
#             output = model(X)
#             loss = loss_func(output, Y)
#             loss.backward()
#             optimizer.step()
#             mean_loss += loss.item()
#         mean_loss /= len(train_loader.dataset)
#         loss_data.append(mean_loss)
#         print('Epoch%d\tTraining Loss: %.6f, time=%.2f' % (ep + 1, mean_loss, time.time()-start_time))
#
#         if not (ep+1) % eval_freq:
#             train_accu = accuracy(model, original_train_loader)
#             test_accu = accuracy(model, test_loader)
#             print('Accuracy: train set%.1f%%, test set%.1f%%' % (train_accu*100, test_accu*100))
#             accu_data.append((train_accu, test_accu))
#
#         if not (ep+1) % save_freq:
#             torch.save(model.state_dict(), './%s/CNN_%d_dict.pkl' % (result_path, ep + 1))
#             with open('./%s/loss_data.json' % result_path, 'w') as f:
#                 json.dump(loss_data, f)
#             with open('./%s/accu_data.json' % result_path, 'w') as f:
#                 json.dump(accu_data, f)
#             t = int(time.time() - start_time)
#             with open('./%s/Summary.txt' % result_path, 'w') as f:
#                 f.write('Total time:%d:%d:%d, Epochs:%d, Average time per epoch: %.1f' %
#                         (t//3600, (t%3600)//60, t%60, ep+1, t/(ep+1)))
#
# def main(gpu=False):
#     """
#     Main function
#     """
#     train(gpu)
#
# if __name__ == '__main__':
#     # Command line arguments
#     parser = argparse.ArgumentParser()
#     parser.add_argument('--learning_rate', type = float, default = LEARNING_RATE_DEFAULT,
#                       help='Learning rate')
#     parser.add_argument('--max_steps', type = int, default = MAX_EPOCHS_DEFAULT,
#                       help='Number of steps to run trainer.')
#     parser.add_argument('--batch_size', type = int, default = BATCH_SIZE_DEFAULT,
#                       help='Batch size to run trainer.')
#     parser.add_argument('--eval_freq', type=int, default=EVAL_FREQ_DEFAULT,
#                         help='Frequency of evaluation on the test set')
#     parser.add_argument('--using_gpu', type=bool, default=USING_GPU_DEFAULT,
#                         help='Using GPU or not')
#     parser.add_argument('--weight_penal', type=float, default=WEIGHT_PENAL_DEFAULT,
#                         help='Parameter of L2 regularization')
#     parser.add_argument('--data_augmentation', type = bool, default = DATA_AUGMENTATION_DEFAULT,
#                         help='Use data augmentation or not')
#     parser.add_argument('--result_path', type=str, default=RESULT_PATH_DEFAULT,
#                         help='Directory for storing result data and model')
#     parser.add_argument('--threads', type=int, default=THREADS_DEFAULT,
#                         help='How many sub threads will be used to process training data')
#     FLAGS, unparsed = parser.parse_known_args()
#
#     lr = FLAGS.learning_rate
#     max_steps = FLAGS.max_steps
#     batch_size = FLAGS.batch_size
#     eval_freq = FLAGS.eval_freq
#     gpu = FLAGS.using_gpu
#     weight_penal = FLAGS.weight_penal
#     data_augmentation = FLAGS.data_augmentation
#     result_path = FLAGS.result_path
#     threads = FLAGS.threads
#     if data_augmentation:
#         tsf = transforms.Compose([
#             transforms.RandomApply([
#                 transforms.RandomChoice([
#                     transforms.Resize(28),
#                     transforms.Resize(24),
#                     transforms.Resize(20)
#                 ]),
#                 transforms.RandomHorizontalFlip(),
#                 transforms.ColorJitter(brightness=0.5, contrast=0.5, hue=0.5),
#                 torchvision.transforms.RandomRotation(15),
#                 ], p=0.4),
#             transforms.RandomChoice([
#                 transforms.RandomResizedCrop(32, (0.6, 1.0), ratio=(0.85, 1.2)),
#                 transforms.Resize(32)
#             ]),
#             transforms.ToTensor(),
#             transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
#         ])
#     else:
#         tsf = transforms.ToTensor()
#
#     train_set = torchvision.datasets.CIFAR10(
#         root='./data', train=True, download=True, transform=tsf)
#     train_loader = DataLoader(
#         train_set, batch_size=batch_size, shuffle=True, num_workers=threads, pin_memory=gpu)
#
#     original_train_set = torchvision.datasets.CIFAR10(
#         root='./data', train=True, download=True, transform=transforms.ToTensor())
#     original_train_loader = DataLoader(
#         original_train_set, batch_size=batch_size, shuffle=True, num_workers=threads, pin_memory=gpu)
#
#
#     test_set = torchvision.datasets.CIFAR10(
#         root='./data', train=False, download=True, transform=transforms.ToTensor())
#     test_loader = DataLoader(
#         test_set, batch_size=batch_size, shuffle=False, num_workers=threads, pin_memory=gpu)
#
#     torch.cuda.set_device(3)
#     main(gpu)
