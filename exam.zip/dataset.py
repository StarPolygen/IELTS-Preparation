from torch.utils.data import Dataset
from torchvision.datasets.vision import VisionDataset
from PIL import Image

def load_image(path):
    img = Image.open(path)
    img.load()
    return img


class BaseDataset(Dataset):
    def __init__(self, transforms, train=True):
        fmt = '/home/group4/wangziqi/dataset/'
        fmt += 'train' if train else 'validation'
        fmt += '_set_128/img_%d.jpg'

        if train:
            self.data = [load_image(fmt % i) for i in range(1, 748 + 1)]
            with open('/home/group4/wangziqi/dataset/training_set.csv', 'r') as f:
                lines = [line.split(',') for line in f.readlines()]
            self.labels = [int(row[-1].strip()) for row in lines[1:]]
            assert len(self.data) == len(self.labels)
        else:
            self.data = [load_image(fmt % i) for i in range(1, 186 + 1)]
            with open('/home/group4/wangziqi/dataset/validation_set.csv', 'r') as f:
                lines = [line.split(',') for line in f.readlines()]
            self.labels = [int(row[-1].strip()) for row in lines[1:]]
            assert len(self.data) == len(self.labels)

        self.transforms = transforms
        print('train set' if train else 'validation set', end=' ')
        print('initialized')

    def __getitem__(self, item):
        return self.transforms(self.data[item]), self.labels[item]

    def __len__(self):
        return len(self.data)

#
# class MyDataset(VisionDataset):
#     def __init__(self, root, train=True):
#         super().__init__(root)
#         fmt = '/home/group4/wangziqi/dataset/' + \
#               'train' if train else 'validation' + \
#               '_set_128/img_%d.jpg'
#
#         if train:
#             self.all = [Image.open(fmt % i, 'r') for i in range(1, 748+1)]
#         else:
#             self.all = [Image.open(fmt % i, 'r') for i in range(1, 186+1)]
#
#     def __getitem__(self, item):
#         return self.all[item]
#
#     def __len__(self):
#         return len(self.all)
