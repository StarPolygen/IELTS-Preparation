from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import torch.nn as nn
from torch import Tensor, randn

class CNN(nn.Module):
    def __init__(self, n_channels=3, n_classes=2):
        """
        Initializes CNN object.

        Args:
            n_channels: number of input channels
            n_classes: number of classes of the classification problem
        """
        super().__init__()
        self.convLayers = nn.Sequential(
            nn.Conv2d(n_channels, 64, 4, 2, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            # 64*64*64
            nn.Conv2d(64, 64, 4, 2, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(64, 64, 3, 1, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            # 32*32*64
            nn.MaxPool2d(4, 2, 1),
            # 16*16*64

            nn.Conv2d(64, 128, 3, 1, 1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d(3, 2, 1),
            # 8*8*128

            nn.Conv2d(128, 256, 3, 1, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.Conv2d(256, 256, 3, 1, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.MaxPool2d(3, 2, 1),
            # 4*4*256

            nn.Conv2d(256, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.Conv2d(512, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.MaxPool2d(3, 2, 1),
            # 2*2*512
        )
        self.FC = nn.Linear(2048, n_classes)

    def forward(self, x):
        """
        Performs forward pass of the input.
        Args:
            x: input to the network
        Returns:
            out: outputs of the network
        """
        if not isinstance(x, Tensor):
            x = Tensor(x)
        tmp = self.convLayers(x)
        return self.FC(tmp.view(-1, 2048))

if __name__ == '__main__':
    model = CNN()
    net_input = randn(1, 3, 128, 128)
    print(model(net_input))
