from PIL import Image

if __name__ == '__main__':
    for i in range(1, 748+1):

        img = Image.open('/home/group4/wangziqi/dataset/Training_set/img_%d.jpg' % i)

        out = img.resize((128, 128))

        out.save('/home/group4/wangziqi/dataset/train_set_128/img_%d.jpg' % i)

    for i in range(1, 186+1):
        img = Image.open('/home/group4/wangziqi/dataset/Validation_set/img_%d.jpg' % i)

        out = img.resize((128, 128))

        out.save('/home/group4/wangziqi/dataset/validation_set_128/img_%d.jpg' % i)
